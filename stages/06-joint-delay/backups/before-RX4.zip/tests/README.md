# Repeatable Checks

Use `C:\Tools\Embedded\venv\Scripts\python.exe` on the configured Windows computer. Live hardware tests require exclusive access to the Pico port; close the GUI first.

## Current RX3 direction diagnostics

- `verify_direction_diagnostics.py`: 20 targeted confirmation, motion, raw recording, storage-bound and replay-integrity checks. No hardware or playback; writes RX3 evidence.
- `verify_highband_20k.py --output stages/05-direction-diagnostics/model-validation.json`: existing signal/noise/reflection regression with an explicit output location.
- `verify_controls.py --output stages/05-direction-diagnostics/controls-validation.json`: scan/cancellation regression; previous evidence is preserved.
- `replay_direction_diagnostics.py <snapshot JSON>`: verify a local raw NPZ and replay identical audio through RX2 and RX3. Writes under RX3 `replays/`; no device or audio output.
- `explore_direction_capture.py <snapshot JSON> ...`: offline single-burst experiment; never changes the active estimator.
- `analyze_delay_closure.py <replay JSON> ...`: check pair-delay consistency before geometry fitting.

Automatic raw JSON/NPZ pairs are in `SEN0325-Pico-Setup/logs/direction-diagnostics/`. Follow the RX3 README for trigger limits and context. Snapshots have no measured true bearing; replay acceptance is not angle accuracy. Actual GUI smoke evidence is also retained in RX3.

## Preserved RX2 latency checkpoint

- `benchmark_latency.py --name trial --packets 100`: actual ambient Pico capture and per-stage host/device timings; requires exclusive serial access. `--log <path>` summarizes an existing log without opening the port. Results go to `stages/04-latency-reduction/`.
- `verify_crc32_hardware.py`: validates the actual v0.6 firmware against three independent zlib CRC vectors. Waits for USB re-enumeration; writes RX2 evidence.
- `verify_packet_recovery_hardware.py --output-folder <absolute RX2 stage folder>`: checks that corruption/stalled-read recovery remains valid with the accelerated firmware; RX2 is also its default output folder.
- The existing packet/control checks and 20 s real GUI smoke check are also part of RX2 validation. They emit no test sound.

## RX1 transport checks

- `verify_raw_packet.py`: 14 deterministic framing, checksum, cancellation and recovery checks; no hardware or playback. Includes partial headers/trailers and a lost first STOP acknowledgement.
- `verify_controls.py`: scan-only controls, receiver state and cancellation of a burst after Stop; no hardware or playback.
- `verify_packet_recovery_hardware.py`: actual Pico reads with one deliberately flipped host-side byte and one simulated host-read stall. Tests packet rejection and recovery, not physical direction accuracy. Does not change firmware or emit sound.
- `probe_packet_timing.py --seconds 35 --name trial-name`: bounded ambient hardware timing run. `--log <launcher log>` summarizes an existing run without opening the port.
- `SEN0325-Pico-Setup/sen0325_launcher.py --ui-smoke-test 20 --profile coded-20`: actual GUI and Pico checks, including temporary start/stop/profile/import operations. Does not emit sound. This app entry is in the sibling application folder, not this tests folder.

Historical RX1 evidence remains under `stages/03-packet-timing/`; current scripts default to the RX2 stage. Live launcher logs remain under `SEN0325-Pico-Setup/logs/`. Stop/profile cancellations can produce expected sequence gaps and are separate from integrity errors.

## Receiver checks and historical evidence

- `verify_highband_20k.py`: generated 20 kHz code, angle/noise/reflection/negative-input regression. Model evidence, not physical acceptance.
- `verify_beacon_import.py`: compatible reference import, wrong-code rejection and preservation of preset state.
- `verify_english_ui.py`: real Tk labels/layout using a disconnected worker; no serial device or playback.
- `verify_arrival_scope.py`, `verify_highband_stage1.py`: earlier 16–18 kHz stage evidence and scope tests.
- `verify_beacon_model.py`: earlier audible/ultrasonic model regression.
- `diagnose_delay_pipeline.py`: frozen historical log analysis for the 22 October diagnosis.

The rejected hard direction-guard test is retained only under `stages/02-20kHz/rejected-guard-policy/`; it is not a current regression requirement. Earlier scripts write reports to their respective stage folders. Original weekly bench reports remain under `reports/validation/`.

For physical trials, use Advanced → Record 10 s and enter the actual measured distance. The app saves JSON metrics and raw seven-channel NPZ. Record physical phone position separately; a distance label does not establish a known true angle.
