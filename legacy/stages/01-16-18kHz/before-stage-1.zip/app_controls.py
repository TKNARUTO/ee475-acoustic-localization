"""Independent acquisition and local playback controls for the simple UI."""
from pathlib import Path

PROFILES={'Audible beacon':'coded-audible','High-frequency (experimental)':'coded-ultrasonic'}

class WindowsSound:
    def play(self,path):
        import winsound
        winsound.PlaySound(str(path),winsound.SND_FILENAME|winsound.SND_ASYNC|winsound.SND_LOOP|winsound.SND_NODEFAULT)

    def stop(self):
        import winsound
        winsound.PlaySound(None,0)

class Playback:
    def __init__(self,root,backend=None):
        self.root=Path(root)
        self.backend=backend or WindowsSound()
        self.playing=False
        self.path=None

    def start(self,profile):
        from beacon_dsp import prepare_beacon
        path=prepare_beacon(self.root,profile,single_speaker=True)
        self.backend.play(path)
        self.path=path
        self.playing=True

    def stop(self):
        if self.playing:
            self.backend.stop()
            self.playing=False

class IndependentControls:
    def __init__(self,session,player):
        self.session=session
        self.player=player
        self.profile='coded-audible'
        self.session.set_running(False)
        self.session.set_mode(self.profile)

    @property
    def running(self):
        return self.session.want_running.is_set()

    def toggle_radar(self):
        self.session.set_running(not self.running)

    def toggle_playback(self):
        if self.player.playing:
            self.player.stop()
        else:
            self.player.start(self.profile)

    def select_audio(self,profile):
        if profile not in PROFILES.values():
            raise ValueError('Unknown audio profile')
        if profile==self.profile:
            return
        # Changing the selected file cancels local playback. Acquisition keeps
        # its on/off state while its detector is configured for the new file.
        self.player.stop()
        self.profile=profile
        self.session.set_mode(profile)

    def close(self):
        self.player.stop()
        self.session.set_running(False)
        self.session.stop.set()

class SilentTestSound:
    """Exercises the real button paths without making sound during UI checks."""
    def __init__(self):
        self.calls=[]
    def play(self,path):
        self.calls.append(('play',str(path)))
    def stop(self):
        self.calls.append(('stop',None))
